package com.example.musickotlin

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.widget.SeekBar
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.bumptech.glide.Glide
import com.example.musickotlin.databinding.ActivityPlayerBinding
import java.lang.Exception

class PlayerActivity : AppCompatActivity(),ServiceConnection,MediaPlayer.OnCompletionListener {
    private lateinit var runnable:Runnable
    companion object{
        lateinit var playeractivityMusicList: ArrayList<MusicClass>
        var songpos:Int=0
        //var mediaplayer:MediaPlayer?=null
        var isplaying:Boolean=false
        var musicservice :MusicService?=null
        lateinit var binding: ActivityPlayerBinding
        fun setLayout(context:Context){
            val image:ByteArray?=MainActivity.getAlbumArt(playeractivityMusicList.get(songpos).path)
            if (image != null) {
                Glide.with(context).asBitmap().load(image).into(binding.playeractivityalbumart)
            } else {
                Glide.with(context).load(R.drawable.ic_launcher_foreground).into(binding.playeractivityalbumart)
            }
            binding.playeractivitysongname.text= playeractivityMusicList.get(songpos).title
        }
    }

    private lateinit var appBarConfiguration: AppBarConfiguration

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val intent=Intent(this,MusicService::class.java)
        bindService(intent,this, BIND_AUTO_CREATE)
        startService(intent)
        initlayout()
        binding.playbutton.setOnClickListener{if (isplaying){pausemusic()}else{playmusic()}}
        binding.nextbutton.setOnClickListener { playnextsong(true) }
        binding.prevbutton.setOnClickListener { playnextsong(false) }
        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                try {
                    if (fromUser){
                        musicservice!!.mediaPlayer!!.seekTo(progress)
                    }
                }catch (e:Exception){
                    Log.e("error", e.toString())
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                Unit
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                Unit
            }
        })
//        binding.startduration.text= formatsongDuration(musicservice!!.mediaPlayer!!.currentPosition.toLong())
//        binding.totalduration.text= formatsongDuration(musicservice!!.mediaPlayer!!.duration.toLong())
//        binding.seekBar.progress=0
//        binding.seekBar.max= musicservice!!.mediaPlayer!!.duration
    }

    private fun initlayout(){
        songpos=intent.getIntExtra("position",0)
        when(intent.getStringExtra("class")){
            "songadapter"->{
                playeractivityMusicList= ArrayList()
                playeractivityMusicList.addAll(MainActivity.MusiclistMainactivity)
                setLayout(this)
                //createmediaplayer()
            }
        }
    }

    private fun createmediaplayer(){
        if (musicservice!!.mediaPlayer==null){
            musicservice!!.mediaPlayer= MediaPlayer()
            musicservice!!.mediaPlayer!!.reset()
            musicservice!!.mediaPlayer!!.setDataSource(playeractivityMusicList.get(songpos).path)
            musicservice!!.mediaPlayer!!.prepare()
            binding.startduration.text= formatsongDuration(musicservice!!.mediaPlayer!!.currentPosition.toLong())
            binding.totalduration.text= formatsongDuration(musicservice!!.mediaPlayer!!.duration.toLong())
            binding.seekBar.progress=0
            binding.seekBar.max= musicservice!!.mediaPlayer!!.duration
            musicservice!!.mediaPlayer!!.start()
            isplaying=true
            binding.playbutton.setImageResource(R.drawable.pause_img)
            musicservice!!.mediaPlayer!!.setOnCompletionListener ( this )
        }else{
//            mediaplayer= MediaPlayer()
            musicservice!!.mediaPlayer!!.reset()
            musicservice!!.mediaPlayer!!.setDataSource(playeractivityMusicList.get(songpos).path)
            musicservice!!.mediaPlayer!!.prepare()
            binding.startduration.text= formatsongDuration(musicservice!!.mediaPlayer!!.currentPosition.toLong())
            binding.totalduration.text= formatsongDuration(musicservice!!.mediaPlayer!!.duration.toLong())
            binding.seekBar.progress=0
            binding.seekBar.max= musicservice!!.mediaPlayer!!.duration
            musicservice!!.mediaPlayer!!.start()
            isplaying=true
            binding.playbutton.setImageResource(R.drawable.pause_img)
            musicservice!!.mediaPlayer!!.setOnCompletionListener ( this )
        }
    }


    private fun playmusic(){
        binding.playbutton.setImageResource(R.drawable.pause_img)
        musicservice!!.showNotification(R.drawable.pause_img)
        musicservice!!.mediaPlayer!!.start()
        isplaying=true
    }

    private fun pausemusic(){
        binding.playbutton.setImageResource(R.drawable.play_img)
        musicservice!!.showNotification(R.drawable.play_img)
        musicservice!!.mediaPlayer!!.pause()
        isplaying=false
    }

    fun playnextsong(increment:Boolean){
        if (increment){
            if (songpos==playeractivityMusicList.size-1){
                songpos=0
            }else{
                songpos= songpos+1
            }
            setLayout(this)
            createmediaplayer()
            musicservice!!.showNotification(R.drawable.pause_img)
        }else{
            if (songpos==0){
                songpos=0
            }else{
                songpos= songpos-1
            }
            setLayout(this)
            createmediaplayer()
            musicservice!!.showNotification(R.drawable.pause_img)
        }
    }

//    override fun onSupportNavigateUp(): Boolean {
//        val navController = findNavController(R.id.nav_host_fragment_content_player)
//        return navController.navigateUp(appBarConfiguration)
//                || super.onSupportNavigateUp()
//    }

    override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
        val binder=service as MusicService.MyBinder
        musicservice=binder.currentService()
        createmediaplayer()
        musicservice!!.showNotification(R.drawable.pause_img)
        seekBarSetup()
    }

    override fun onServiceDisconnected(name: ComponentName?) {
        musicservice=null
    }

    fun seekBarSetup(){
        runnable = Runnable {
           binding.startduration.text= formatsongDuration(musicservice!!.mediaPlayer!!.currentPosition.toLong())
           binding.seekBar.progress= musicservice!!.mediaPlayer!!.currentPosition
           Handler(Looper.getMainLooper()).postDelayed(runnable,200)
       }
        Handler(Looper.getMainLooper()).postDelayed(runnable,0)
    }

    override fun onCompletion(mp: MediaPlayer?) {
            playnextsong(true)
    }
}
package com.example.musickotlin

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Menu
import android.widget.Toast
import android.widget.Toolbar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2
import com.example.musickotlin.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayout
import java.io.File
import java.io.IOException


class MainActivity : AppCompatActivity() {
    @SuppressLint("SuspiciousIndentation")
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.search_view_menu,menu)
        val searchItem = menu?.findItem(R.id.searchView)
        val searchview = searchItem?.actionView as? SearchView
        if (searchview != null) {
            searchview.queryHint="dfghjk"
                if (searchItem == null) {
                    Toast.makeText(this, "Search MenuItem is null", Toast.LENGTH_SHORT).show()
                    return true
                }
        }
        if (searchview == null) {
            Toast.makeText(this, "SearchView is null", Toast.LENGTH_SHORT).show()
        }
        searchview?.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                Toast.makeText(this@MainActivity,newText,Toast.LENGTH_SHORT).show()
                return true
            }
        })
        return super.onCreateOptionsMenu(menu)
    }

    lateinit var tab:TabLayout;
    lateinit var viewpager:ViewPager2;
    private lateinit var binder: ActivityMainBinding;
    private lateinit var fragmentadapter: FragmentPagerAdapter
    companion object{
        lateinit var MusiclistMainactivity:ArrayList<MusicClass>
        fun getAlbumArt(uri: String?): ByteArray? {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(uri)
            val art = retriever.embeddedPicture
            try {
                retriever.release()
            } catch (e: IOException) {
                throw RuntimeException(e)
            }
            return art
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binder = ActivityMainBinding.inflate(layoutInflater);
        setContentView(binder.root)
        requestRuntimePermission()
        setSupportActionBar(binder.toolbar)
    }
    private fun addFragments(){
        fragmentadapter.addFragment(SongFragment())
        fragmentadapter.addFragment(AlbumFragment())
        fragmentadapter.addFragment(FavouriteFragment())
        fragmentadapter.addFragment(PlaylistFragment())
    }



    private fun requestRuntimePermission(){
        if (Build.VERSION.SDK_INT>=33){
            if (ActivityCompat.checkSelfPermission(this,android.Manifest.permission.READ_MEDIA_AUDIO)!=PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.READ_MEDIA_AUDIO),9)
                Toast.makeText(this,"permission not granted",Toast.LENGTH_SHORT).show()
            }else{
                MusiclistMainactivity=getAllAudio()
                initviews()
            }
        }else{
            if (ActivityCompat.checkSelfPermission(this,android.Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE),9)
                Toast.makeText(this,"permission not granted",Toast.LENGTH_SHORT).show()
            }else{
                MusiclistMainactivity=getAllAudio()
                initviews()
            }
        }

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode==9){
            if (grantResults.isNotEmpty()&&grantResults[0]==PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"permission granted",Toast.LENGTH_SHORT).show()
                MusiclistMainactivity=getAllAudio()
                initviews()
            }else{
                requestRuntimePermission()
            }
        }
    }
    @SuppressLint("Range")
    private fun getAllAudio():ArrayList<MusicClass>{
        val tempList = ArrayList<MusicClass>()
        val selection = MediaStore.Audio.Media.IS_MUSIC+"!=0"
        val projection = arrayOf(MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.DISPLAY_NAME,MediaStore.Audio.Media.ARTIST,MediaStore.Audio.Media.DATE_ADDED,MediaStore.Audio.Media.DURATION,MediaStore.Audio.Media.DATA,MediaStore.Audio.Media.ALBUM)
        val cursor = this.contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,projection,selection,null,null,null)
        if (cursor!=null){
            if (cursor.moveToFirst()){
                do {
                var cursortitle =cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE))
                var cursorid=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media._ID))
                    var cursoralbum = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM))
                    var cursorartist = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST))
                    var cursorduration=cursor.getLong(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION))
                    var cursorsongpath=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA))
                    val fetchedmusic =MusicClass(id = cursorid, album = cursoralbum, title = cursortitle, duration = cursorduration, artist = cursorartist, path = cursorsongpath)
                    val file=File(fetchedmusic.path)
                    if (file.exists()){
                        tempList.add(fetchedmusic)
                    }
                }while (cursor.moveToNext())
                cursor.close()
            }
        }
        return tempList
    }
    private fun initviews(){
        tab=binder.tablayout
        viewpager=binder.viewpager
        fragmentadapter= FragmentPagerAdapter(supportFragmentManager,lifecycle)
        addFragments()
        tab.addTab(tab.newTab().setText("Songs"))
        tab.addTab(tab.newTab().setText("Albums"))
        tab.addTab(tab.newTab().setText("Favourite"))
        tab.addTab(tab.newTab().setText("Playlists"))
        viewpager.adapter=fragmentadapter
        tab.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener{
            @SuppressLint("SuspiciousIndentation")
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if (tab!=null)
                    viewpager.currentItem=tab.position
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {

            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
            }
        })
        viewpager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                tab.selectTab(tab.getTabAt(position))  // Select the corresponding tab based on position
            }
        })
    }
}